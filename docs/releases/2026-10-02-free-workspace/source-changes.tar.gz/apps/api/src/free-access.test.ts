import { Client, StreamableHTTPClientTransport } from '@modelcontextprotocol/client';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { buildNodeApp } from './node-app';
import { readConfig } from './config';
import { SupabaseTokenVerifier } from './auth';
const { rpc } = vi.hoisted(() => ({ rpc: vi.fn() }));
vi.mock('@supabase/supabase-js', () => ({ createClient: () => ({ rpc }) }));
const config = readConfig({ NODE_ENV: 'test', SUPABASE_URL: 'https://example.supabase.co', SUPABASE_ANON_KEY: 'local-test-public-key-value' });
const headers = { Host: 'localhost', Authorization: 'Bearer valid-test-token' };
afterEach(() => vi.restoreAllMocks());
beforeEach(() => {
  rpc.mockReset().mockRejectedValue(new Error('Billing unavailable'));
  vi.spyOn(Date, 'now').mockReturnValue(Date.parse('2026-10-10T12:00:00Z'));
  vi.spyOn(SupabaseTokenVerifier.prototype, 'verifyAccessToken').mockImplementation(async token => ({ token, clientId: 'test-user', scopes: ['openid'], expiresAt: 4102444800 }));
});
describe('production campaign access', () => {
  it('returns HTTP source for an authenticated unsubscribed user without billing access', async () => {
    const app = await buildNodeApp(config);
    const response = await app.request('http://localhost/api/components/button/source', { headers });
    expect(response.status).toBe(200);
    expect((await response.json()).entitlement).toMatchObject({ allowed: true, plan_code: 'free_access', access_ends_at: '2026-11-02T00:00:00.000Z' });
    expect(rpc).not.toHaveBeenCalled();
  });
  it('returns all component files through authenticated MCP', async () => {
    const app = await buildNodeApp(config);
    const client = new Client({ name: 'free-access-release-test', version: '1' });
    try {
      await client.connect(new StreamableHTTPClientTransport(new URL('http://localhost/mcp'), { requestInit: { headers }, fetch: async (input, init) => app.fetch(new Request(input, init)) }));
      const result = await client.callTool({ name: 'get_component', arguments: { id: 'beui:button' } });
      expect(result.isError).not.toBe(true);
      const payload = JSON.parse(result.content.find(item => item.type === 'text')!.text);
      expect(payload.component.files.length).toBeGreaterThan(0);
      expect(payload.entitlement.plan_code).toBe('free_access');
      expect(rpc).not.toHaveBeenCalled();
    } finally { await client.close(); }
  });
  it('rejects invalid tokens and missing scopes during the free period', async () => {
    const app = await buildNodeApp(config);
    vi.spyOn(SupabaseTokenVerifier.prototype, 'verifyAccessToken').mockRejectedValue(new Error('Invalid token'));
    expect((await app.request('http://localhost/api/components/button/source', { headers })).status).toBe(401);
    vi.spyOn(SupabaseTokenVerifier.prototype, 'verifyAccessToken').mockImplementation(async token => ({ token, clientId: 'test-user', scopes: [], expiresAt: 4102444800 }));
    expect((await app.request('http://localhost/mcp', { headers })).status).toBe(403);
  });
  it('restores the paid boundary exactly at the campaign end', async () => {
    vi.spyOn(Date, 'now').mockReturnValue(Date.parse('2026-11-02T00:00:00.000Z'));
    rpc.mockResolvedValue({ data: [{ allowed: false, plan_code: null, subscription_status: null, trial_end: null, current_period_end: null, cancel_at_period_end: false }], error: null });
    const app = await buildNodeApp(config);
    expect((await app.request('http://localhost/mcp', { headers })).status).toBe(402);
    expect(rpc).toHaveBeenCalledWith('get_subscription_access');
  });
});
