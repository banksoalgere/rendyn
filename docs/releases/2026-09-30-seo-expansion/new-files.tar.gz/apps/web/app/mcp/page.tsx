/* eslint-disable @next/next/no-html-link-for-pages -- Native anchors follow the existing Vinext site shell. */
import '../globals.css';
import { pageMetadata, siteOrigin } from '../../lib/seo';
import { SiteHeader } from '../components/site-header';
import { SiteFooter } from '../components/site-footer';
import { CodeExample } from './code-example';
import styles from './mcp.module.css';

export const metadata = pageMetadata(
  'UI Component MCP Server for Claude Code, Cursor & Codex | Rendyn',
  'Find React UI components through MCP. Compare previews, retrieve TypeScript source and dependencies, and connect Rendyn to Claude Code, Cursor or Codex.',
  '/mcp',
);

const endpoint = 'https://mcp.rendyn.dev/mcp';
const contents = [
  ['access', 'Access'], ['workflow', 'Workflow'], ['tools', 'Tools'],
  ['connect', 'Client setup'], ['choosing', 'Choosing a server'], ['faq', 'FAQ'],
];

const tools = [
  ['search_components', 'Find a small ranked shortlist for one UI need.', 'query; optional limit (1–5), category, include_previews'],
  ['get_component', 'Retrieve source files, dependencies, install steps, source hashes and licence details.', 'id from a search or browse result'],
  ['list_categories', 'See the available categories and their descriptions.', 'No arguments'],
  ['browse_category', 'Explore a category in stable pages.', 'category; optional cursor and limit (1–50)'],
];

const approvalPrompt = `Use Rendyn to find a human approval card for reviewing an AI-generated action.
Search one UI need, compare the returned preview links, and explain the fit.
Retrieve the chosen component with get_component using its returned id.
Inspect every source file, dependency and licence notice before editing.
Reuse our existing tokens and primitives; list any missing dependencies.
Connect the UI to our existing approval API. Keep authorization on the server.
Check pending, approved and rejected states, keyboard focus and mobile layout.`;

const structuredData = {
  '@context': 'https://schema.org',
  '@type': 'WebPage',
  name: 'Rendyn UI component MCP server',
  url: `${siteOrigin}/mcp`,
  description: metadata.description,
  isPartOf: { '@id': `${siteOrigin}/#website` },
  breadcrumb: {
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Rendyn', item: siteOrigin },
      { '@type': 'ListItem', position: 2, name: 'MCP', item: `${siteOrigin}/mcp` },
    ],
  },
};

export default function McpPage() {
  return (
    <div className={styles.page}>
      <SiteHeader />
      <main id="main-content">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData).replace(/</g, '\\u003c') }} />
        <section className={`${styles.shell} ${styles.hero}`} aria-labelledby="mcp-title">
          <div>
            <p className={styles.eyebrow}>UI component MCP server</p>
            <h1 id="mcp-title">React UI, ready for<br />your coding agent.</h1>
            <p className={styles.lead}>Give Claude Code, Cursor or Codex a component catalogue it can query. Search by UI intent, compare working previews, then retrieve the source and setup context to adapt the result.</p>
            <div className={styles.actions}>
              <a className="button" href="#connect">Connect your agent <span aria-hidden="true">↗</span></a>
              <a className={styles.textLink} href="/components">Browse components <span aria-hidden="true">→</span></a>
            </div>
            <p className={styles.accessNote}>MCP requires a Rendyn account with an active trial or paid subscription.</p>
          </div>
          <div className={styles.workflowCard} aria-label="Example component discovery workflow">
            <div className={styles.cardTop}><span>Rendyn → your editor</span><span>React · TypeScript</span></div>
            <ol>
              <li><span>01</span><div><small>Describe one need</small><p>“A human approval card for an AI action”</p></div></li>
              <li><span>02</span><div><small>Compare candidates</small><p>Approval Card <span className={styles.tag}>Agent UI</span></p><a href="/components/approval-card">Open component & preview <span aria-hidden="true">↗</span></a></div></li>
              <li><span>03</span><div><small>Retrieve the implementation</small><p><code>get_component</code></p><div className={styles.fileTags}><span>Source files</span><span>Dependencies</span><span>MIT notice</span></div></div></li>
            </ol>
            <p className={styles.cardNote}>Your coding agent adapts the files in your project.</p>
          </div>
        </section>

        <nav className={`${styles.shell} ${styles.contents}`} aria-label="On this page">
          {contents.map(([id, label]) => <a href={`#${id}`} key={id}>{label}</a>)}
        </nav>

        <div className={styles.shell}>
          <section className={styles.section} id="access" aria-labelledby="access-title">
            <p className={styles.eyebrow}>Before you connect</p>
            <h2 id="access-title">Choose how you want to use the catalogue.</h2>
            <div className={styles.twoColumns}>
              <div className={styles.infoCard}>
                <h3>Browse and copy on the website</h3>
                <p>Explore components and interactive previews publicly. Log in to view and copy component source on the website for free, without a subscription.</p>
                <a className={styles.textLink} href="/components">Explore the catalogue <span aria-hidden="true">→</span></a>
              </div>
              <div className={`${styles.infoCard} ${styles.accentCard}`}>
                <h3>Search and retrieve through MCP</h3>
                <p>All MCP tools require OAuth login and an active trial or paid subscription. Confirm your access in <a href="/account">your account</a>, then authorize Rendyn in your client.</p>
                <p>The seven-day trial collects a card and converts to paid access unless cancelled before it ends. Your coding client’s own account requirements are separate.</p>
                <a className={styles.textLink} href="/pricing">See plans and trial terms <span aria-hidden="true">→</span></a>
              </div>
            </div>
          </section>

          <section className={styles.section} id="workflow" aria-labelledby="workflow-title">
            <p className={styles.eyebrow}>From a brief to usable source</p>
            <h2 id="workflow-title">Find React components through MCP.</h2>
            <p className={styles.intro}>Work one UI need at a time. A shortlist is easier to evaluate than a whole page of unrelated effects. Rendyn returns match reasons and preview links; your agent and your product brief determine the final choice.</p>
            <div className={styles.walkthrough}>
              <div className={styles.step}>
                <span className={styles.stepNumber}>01</span>
                <h3>Search the interaction</h3>
                <p>Start without a category filter. The <code>motion</code> category includes individual UI components such as bento grids and buttons; its name does not mean every result is animated.</p>
                <CodeExample label="search_components arguments" code={`{\n  "query": "approval card",\n  "limit": 2\n}`} />
              </div>
              <div className={styles.step}>
                <span className={styles.stepNumber}>02</span>
                <h3>Review the preview</h3>
                <p>This search can return Approval Card and Tool Approval. Choose the first for a decision or question flow; inspect the second when the user is deciding whether a tool may execute.</p>
                <p>Open the returned <code>preview_url</code>. Search returns metadata by default; use <code>include_previews: true</code> to request available preview images in the tool response.</p>
                <div className={styles.previewLinks}><a href="/components/approval-card">Approval Card ↗</a><a href="/components/tool-approval">Tool Approval ↗</a></div>
              </div>
              <div className={styles.step}>
                <span className={styles.stepNumber}>03</span>
                <h3>Retrieve and adapt</h3>
                <p>Pass the returned ID directly to <code>get_component</code>. Copy every required file, reconcile imports and dependencies with your app, and retain the supplied licence notices.</p>
                <CodeExample label="get_component arguments" code={`{\n  "id": "beui:approval-card"\n}`} />
                <p className={styles.small}>This is a real catalogue ID. Use the IDs returned by your own search for other components.</p>
              </div>
            </div>
            <div className={styles.twoColumns}>
              <div className={styles.infoCard}>
                <h3>Approval Card: source plus shared files</h3>
                <p>The beUI implementation includes <code>components/agents/approval-card/index.tsx</code>, its types, shared input and button files, and utilities. Its external dependencies include <code>clsx</code>, <code>lucide-react</code>, <code>motion</code>, <code>react</code> and <code>tailwind-merge</code>.</p>
                <p>Check the returned dependency command against your existing versions. Set up Tailwind and map <code>@/</code> imports to your source root. Wire callbacks to your application’s state and API.</p>
              </div>
              <div className={styles.infoCard}>
                <h3>Bento Grid: a different dependency path</h3>
                <p>The Magic UI <a href="/components/bento-grid">Bento Grid</a> uses <code>@radix-ui/react-icons</code> and a shadcn button primitive. Its payload includes an external dependency command and a separate registry dependency command.</p>
                <p>Review <code>dependencies</code>, <code>internal_dependencies</code>, <code>install</code>, <code>files</code> and <code>license</code> for each result. A single copied TSX file is not always the entire implementation.</p>
              </div>
            </div>
            <p className={styles.sourceNote}>Examples checked against Rendyn’s catalogue and an authenticated MCP search and source retrieval on 29 September 2026. Catalogue results and dependencies can change.</p>
          </section>

          <section className={styles.section} id="tools" aria-labelledby="tools-title">
            <p className={styles.eyebrow}>A small tool surface</p>
            <h2 id="tools-title">Four tools for component discovery.</h2>
            <div className={styles.tableWrap} tabIndex={0} role="region" aria-label="Rendyn MCP tools, scroll horizontally on narrow screens">
              <table className={styles.toolTable}>
                <caption>Tools available after authentication and trial or paid access</caption>
                <thead><tr><th scope="col">Tool</th><th scope="col">Purpose</th><th scope="col">Inputs</th></tr></thead>
                <tbody>{tools.map(([name, purpose, inputs]) => <tr key={name}><th scope="row"><code>{name}</code></th><td>{purpose}</td><td>{inputs}</td></tr>)}</tbody>
              </table>
            </div>
            <p>Categories are <code>motion</code>, <code>agents</code> and <code>blocks</code>. Use <code>list_categories</code> for their current descriptions. If search finds no close match, adjust the brief or browse for alternatives; do not treat an unrelated result as support for your use case.</p>
          </section>

          <section className={styles.section} id="connect" aria-labelledby="connect-title">
            <p className={styles.eyebrow}>Use the editor you already have</p>
            <h2 id="connect-title">Connect Claude Code, Cursor or Codex.</h2>
            <p className={styles.intro}>Rendyn is a remote Streamable HTTP MCP service. Use the endpoint below and complete the client’s OAuth flow with your Rendyn account. Merge configuration into existing settings so your other servers stay available.</p>
            <CodeExample label="Rendyn MCP endpoint" code={endpoint} />
            <nav className={styles.clientLinks} aria-label="Choose a coding client"><a href="#claude-code">Claude Code</a><a href="#cursor">Cursor</a><a href="#codex">Codex</a></nav>

            <section className={styles.client} id="claude-code" aria-labelledby="claude-title">
              <div className={styles.clientHeading}><span>01</span><div><p className={styles.eyebrow}>Claude Code component workflow</p><h3 id="claude-title">Give Claude concrete UI ingredients.</h3></div></div>
              <p>Run this command in your project. Project scope stores the endpoint in <code>.mcp.json</code>. Accept Claude Code’s project-server approval when prompted, then use <code>/mcp</code> to select Rendyn and complete the browser login and consent.</p>
              <CodeExample label="Claude Code project setup" code={`claude mcp add --transport http rendyn --scope project ${endpoint}`} />
              <p>Check that Rendyn is connected in <code>/mcp</code> and that its tools are available before asking Claude to build. Keep your project’s visual rules in <code>CLAUDE.md</code>; use the component retrieval as implementation context for the current task.</p>
              <CodeExample label="Claude Code approval UI prompt" code={approvalPrompt} />
              <p className={styles.sourceNote}>Setup follows <a href="https://code.claude.com/docs/en/mcp">Anthropic’s official MCP documentation</a>. For the wider design brief and browser review method, read our <a href="/guides/how-to-make-claude-code-better-at-design">Claude Code design workflow</a>.</p>
            </section>

            <section className={styles.client} id="cursor" aria-labelledby="cursor-title">
              <div className={styles.clientHeading}><span>02</span><div><p className={styles.eyebrow}>Cursor UI component library workflow</p><h3 id="cursor-title">Search from the project you are editing.</h3></div></div>
              <p>Add a <code>rendyn</code> entry under <code>mcpServers</code> in your project’s <code>.cursor/mcp.json</code>. For access across projects, Cursor also supports <code>~/.cursor/mcp.json</code>.</p>
              <CodeExample label="Cursor .cursor/mcp.json" code={`{\n  "mcpServers": {\n    "rendyn": {\n      "url": "${endpoint}"\n    }\n  }\n}`} />
              <p>Open Cursor’s MCP settings, enable the server and complete OAuth if prompted. Confirm the tools appear. In Agent, name the UI pattern and ask for a preview comparison before authorizing file changes. Keep your existing project rules and component system in the brief.</p>
              <CodeExample label="Cursor feature section prompt" code={`Use Rendyn to search for a bento grid for our product features.
Compare the returned preview links and retrieve the chosen result by id.
Review its external and registry dependencies against this project.
Adapt it to our existing Tailwind tokens and button primitive.
Use our real feature copy and verify the section on desktop and mobile.`} />
              <p className={styles.sourceNote}>Configuration and OAuth support follow <a href="https://cursor.com/docs/mcp">Cursor’s official MCP documentation</a>. See our <a href="/guides/cursor-design">Cursor design guide</a> for choosing a visual direction.</p>
            </section>

            <section className={styles.client} id="codex" aria-labelledby="codex-title">
              <div className={styles.clientHeading}><span>03</span><div><p className={styles.eyebrow}>Codex React component workflow</p><h3 id="codex-title">Bring source context into the coding task.</h3></div></div>
              <p>Add this table to <code>~/.codex/config.toml</code>, or to <code>.codex/config.toml</code> for a trusted project. Local Codex clients on the same host share this MCP configuration.</p>
              <CodeExample label="Codex config.toml" code={`[mcp_servers.rendyn]\nurl = "${endpoint}"`} />
              <p>Use the CLI to authorize the configured server and list your configuration. In the Codex terminal UI, <code>/mcp</code> shows active servers. Start a fresh session if the server is not yet available.</p>
              <CodeExample label="Codex MCP login and list" code={`codex mcp login rendyn\ncodex mcp list`} />
              <p>Ask Codex to inspect the repository first, search for one interaction, retrieve a fitting result and explain its integration plan. Include your project’s <code>AGENTS.md</code> rules and require a rendered UI check after implementation.</p>
              <CodeExample label="Codex component integration prompt" code={`Inspect our component system and AGENTS.md first.
Use Rendyn to find a keyboard-first command menu for this admin app.
Compare previews and retrieve the best fitting component by returned id.
Explain the source files, dependencies and alias changes it needs.
Adapt it to our real commands and permissions, preserving our design tokens.
Verify keyboard navigation, focus, empty results and mobile layout.`} />
              <p className={styles.sourceNote}>Streamable HTTP, OAuth and configuration follow <a href="https://developers.openai.com/codex/mcp/">OpenAI’s official MCP documentation</a>. Our <a href="/guides/how-to-make-codex-better-at-design">Codex design guide</a> covers the surrounding review loop.</p>
            </section>

            <div className={styles.troubleshooting}>
              <h3>If the connection does not work</h3>
              <ul>
                <li><strong>Needs authentication:</strong> complete the client’s OAuth flow with the Rendyn account that has access.</li>
                <li><strong>Subscription required:</strong> check <a href="/account">your account</a>. A free website login alone does not unlock MCP tools.</li>
                <li><strong>No tools available:</strong> confirm the endpoint ends in <code>/mcp</code>, the server is enabled and your organization permits it.</li>
                <li><strong>No close component match:</strong> remove an unnecessary category filter or use <code>browse_category</code>. A working connection does not mean the catalogue covers every UI.</li>
              </ul>
            </div>
            <p className={styles.sourceNote}>Client instructions checked against official documentation on 29 September 2026. Menus and configuration support may change with client versions.</p>
          </section>

          <section className={styles.section} id="choosing" aria-labelledby="choosing-title">
            <p className={styles.eyebrow}>Choose by the job</p>
            <h2 id="choosing-title">What to look for in a UI component MCP server.</h2>
            <p>Start with your existing design system. <a href="https://ui.shadcn.com/docs/mcp">shadcn’s MCP server</a> browses, searches and installs components from configured registries. <a href="https://magicui.design/docs/mcp">Magic UI</a> offers MCP access to its components, and <a href="https://docs.21st.dev/blog/mcp-ui-components">21st</a> also supports component discovery and installation through an agent.</p>
            <p>Rendyn’s useful path is a bounded shortlist across its curated catalogue, preview links and optional images for comparison, followed by a source handoff with dependencies, install steps, provenance and licence text. Try a specific brief and inspect the actual output to decide whether that path helps your project.</p>
            <p>Some catalogue entries come from beUI, Magic UI and Kibo UI. Their source and notices are attributed in the retrieved payload; these components are also available from their upstream projects. Choose Rendyn for the discovery and handoff workflow when it fits, and reuse the primitives your app already trusts.</p>
            <div className={styles.twoColumns}>
              <div className={styles.infoCard}><h3>Component retrieval through MCP</h3><p>Rendyn gives a coding client UI source and preview context for your React application. Your agent handles repository edits and installation under your project’s permissions.</p></div>
              <div className={styles.infoCard}><h3>MCP Apps and agent runtimes</h3><p><a href="https://modelcontextprotocol.io/extensions/apps/overview">MCP Apps</a> render interactive interfaces inside compatible MCP hosts. Rendyn’s four catalogue tools do not implement that extension. Agent UI components provide the presentation layer; your application still supplies model calls, streaming transport, persistence and server authorization.</p></div>
            </div>
          </section>

          <section className={styles.section} id="faq" aria-labelledby="faq-title">
            <p className={styles.eyebrow}>Practical questions</p>
            <h2 id="faq-title">React components MCP FAQ.</h2>
            <div className={styles.faq}>
              <details><summary>Is Rendyn’s MCP server free?</summary><p>MCP access requires an active seven-day trial or paid subscription. The trial collects a card and converts to paid access unless cancelled before it ends. Website previews are public, and website source access is free after login. See <a href="/pricing">current plans</a>.</p></details>
              <details><summary>Does the MCP server install components automatically?</summary><p>The four Rendyn tools search, browse and retrieve source. They return install instructions and dependencies. Your coding agent executes approved commands and writes files in your project.</p></details>
              <details><summary>Can I use the React components in Next.js?</summary><p>Review the selected component’s client boundary, imports, Tailwind setup and dependency versions against your Next.js project. Interactive components may need a client component boundary. Test the exact route after integration; compatibility depends on the chosen source and your app.</p></details>
              <details><summary>Are agent UI components a complete AI backend?</summary><p>They supply interface pieces such as approval cards, prompt inputs and streaming response views. Your backend and state model handle execution, credentials and authorization. An approval click must be validated by the server before a protected action runs.</p></details>
              <details><summary>What should I do when search returns no match?</summary><p>Narrow the brief to one interaction, remove a category filter or explore a category. If the catalogue still has no fitting component, use your existing primitives or another source. Avoid forcing a visually unrelated result into the feature.</p></details>
            </div>
          </section>

          <section className={styles.finalCta} aria-labelledby="next-title">
            <p className={styles.eyebrow}>Start with one UI need</p>
            <h2 id="next-title">Give your agent a source it can inspect.</h2>
            <p>Explore a component, try its preview, then bring the implementation into your build workflow.</p>
            <div className={styles.actions}><a className="button" href="/components">Browse components <span aria-hidden="true">↗</span></a><a className={styles.textLink} href="#connect">Choose your client <span aria-hidden="true">↑</span></a></div>
          </section>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
